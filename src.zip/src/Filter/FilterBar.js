﻿
import React from 'react';
import SonarFilter from './SonarFilter';


const FilterBar = () => {


    return (
        <div className="Dropdown">
            <div className="dropdown-menu"> <SonarFilter /></div>
                       
        </div>
    )
};


export default FilterBar




