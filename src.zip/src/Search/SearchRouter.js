import React from 'react';

export default function SearchRouter(props) {
    return <h1>Hello, {props.name}</h1>;
  }